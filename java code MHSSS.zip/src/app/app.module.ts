import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { BrowserModule } from '@angular/platform-browser'

import { ComponentsModule } from './components/components.module'
import { AppComponent } from './app.component'

const routes = [
  {
    path: 'popup3',
    loadChildren: () =>
      import('./pages/popup3/popup3.module').then((m) => m.Popup3Module),
  },
  {
    path: 'employee7',
    loadChildren: () =>
      import('./pages/employee7/employee7.module').then(
        (m) => m.Employee7Module
      ),
  },
  {
    path: 'pensioner-home1',
    loadChildren: () =>
      import('./pages/pensioner-home1/pensioner-home1.module').then(
        (m) => m.PensionerHome1Module
      ),
  },
  {
    path: 'g-r-o1',
    loadChildren: () =>
      import('./pages/g-r-o1/g-r-o1.module').then((m) => m.GRO1Module),
  },
  {
    path: 'beneficiary21',
    loadChildren: () =>
      import('./pages/beneficiary21/beneficiary21.module').then(
        (m) => m.Beneficiary21Module
      ),
  },
  {
    path: 'employee11',
    loadChildren: () =>
      import('./pages/employee11/employee11.module').then(
        (m) => m.Employee11Module
      ),
  },
  {
    path: 'beneficiary8',
    loadChildren: () =>
      import('./pages/beneficiary8/beneficiary8.module').then(
        (m) => m.Beneficiary8Module
      ),
  },
  {
    path: 'live-stats4',
    loadChildren: () =>
      import('./pages/live-stats4/live-stats4.module').then(
        (m) => m.LiveStats4Module
      ),
  },
  {
    path: 'employee5',
    loadChildren: () =>
      import('./pages/employee5/employee5.module').then(
        (m) => m.Employee5Module
      ),
  },
  {
    path: 'log-in',
    loadChildren: () =>
      import('./pages/log-in/log-in.module').then((m) => m.LogInModule),
  },
  {
    path: 'pensioner6',
    loadChildren: () =>
      import('./pages/pensioner6/pensioner6.module').then(
        (m) => m.Pensioner6Module
      ),
  },
  {
    path: 'pension-history',
    loadChildren: () =>
      import('./pages/pension-history/pension-history.module').then(
        (m) => m.PensionHistoryModule
      ),
  },
  {
    path: 'beneficiary12',
    loadChildren: () =>
      import('./pages/beneficiary12/beneficiary12.module').then(
        (m) => m.Beneficiary12Module
      ),
  },
  {
    path: 'chief-probation1',
    loadChildren: () =>
      import('./pages/chief-probation1/chief-probation1.module').then(
        (m) => m.ChiefProbation1Module
      ),
  },
  {
    path: 'popup6',
    loadChildren: () =>
      import('./pages/popup6/popup6.module').then((m) => m.Popup6Module),
  },
  {
    path: 'application4',
    loadChildren: () =>
      import('./pages/application4/application4.module').then(
        (m) => m.Application4Module
      ),
  },
  {
    path: 'beneficiary5',
    loadChildren: () =>
      import('./pages/beneficiary5/beneficiary5.module').then(
        (m) => m.Beneficiary5Module
      ),
  },
  {
    path: 'director2',
    loadChildren: () =>
      import('./pages/director2/director2.module').then(
        (m) => m.Director2Module
      ),
  },
  {
    path: 'register',
    loadChildren: () =>
      import('./pages/register/register.module').then((m) => m.RegisterModule),
  },
  {
    path: 'application',
    loadChildren: () =>
      import('./pages/application/application.module').then(
        (m) => m.ApplicationModule
      ),
  },
  {
    path: 'chief-probation11',
    loadChildren: () =>
      import('./pages/chief-probation11/chief-probation11.module').then(
        (m) => m.ChiefProbation11Module
      ),
  },
  {
    path: 'log-in1',
    loadChildren: () =>
      import('./pages/log-in1/log-in1.module').then((m) => m.LogIn1Module),
  },
  {
    path: 'beneficiary3',
    loadChildren: () =>
      import('./pages/beneficiary3/beneficiary3.module').then(
        (m) => m.Beneficiary3Module
      ),
  },
  {
    path: 'beneficiary11',
    loadChildren: () =>
      import('./pages/beneficiary11/beneficiary11.module').then(
        (m) => m.Beneficiary11Module
      ),
  },
  {
    path: 'pensioner-profile1',
    loadChildren: () =>
      import('./pages/pensioner-profile1/pensioner-profile1.module').then(
        (m) => m.PensionerProfile1Module
      ),
  },
  {
    path: 'account-pending',
    loadChildren: () =>
      import('./pages/account-pending/account-pending.module').then(
        (m) => m.AccountPendingModule
      ),
  },
  {
    path: 'social-worker2',
    loadChildren: () =>
      import('./pages/social-worker2/social-worker2.module').then(
        (m) => m.SocialWorker2Module
      ),
  },
  {
    path: 'employee3',
    loadChildren: () =>
      import('./pages/employee3/employee3.module').then(
        (m) => m.Employee3Module
      ),
  },
  {
    path: 'employee6',
    loadChildren: () =>
      import('./pages/employee6/employee6.module').then(
        (m) => m.Employee6Module
      ),
  },
  {
    path: 'accounts2',
    loadChildren: () =>
      import('./pages/accounts2/accounts2.module').then(
        (m) => m.Accounts2Module
      ),
  },
  {
    path: 'application2',
    loadChildren: () =>
      import('./pages/application2/application2.module').then(
        (m) => m.Application2Module
      ),
  },
  {
    path: 'application-status1',
    loadChildren: () =>
      import('./pages/application-status1/application-status1.module').then(
        (m) => m.ApplicationStatus1Module
      ),
  },
  {
    path: 'beneficiary9',
    loadChildren: () =>
      import('./pages/beneficiary9/beneficiary9.module').then(
        (m) => m.Beneficiary9Module
      ),
  },
  {
    path: 'pensioner7',
    loadChildren: () =>
      import('./pages/pensioner7/pensioner7.module').then(
        (m) => m.Pensioner7Module
      ),
  },
  {
    path: 'merchant-home2',
    loadChildren: () =>
      import('./pages/merchant-home2/merchant-home2.module').then(
        (m) => m.MerchantHome2Module
      ),
  },
  {
    path: 'merchant3',
    loadChildren: () =>
      import('./pages/merchant3/merchant3.module').then(
        (m) => m.Merchant3Module
      ),
  },
  {
    path: 'pensioner2',
    loadChildren: () =>
      import('./pages/pensioner2/pensioner2.module').then(
        (m) => m.Pensioner2Module
      ),
  },
  {
    path: 'application3',
    loadChildren: () =>
      import('./pages/application3/application3.module').then(
        (m) => m.Application3Module
      ),
  },
  {
    path: 'application-status3',
    loadChildren: () =>
      import('./pages/application-status3/application-status3.module').then(
        (m) => m.ApplicationStatus3Module
      ),
  },
  {
    path: 'employee1',
    loadChildren: () =>
      import('./pages/employee1/employee1.module').then(
        (m) => m.Employee1Module
      ),
  },
  {
    path: 'social-worker4',
    loadChildren: () =>
      import('./pages/social-worker4/social-worker4.module').then(
        (m) => m.SocialWorker4Module
      ),
  },
  {
    path: 'popup4',
    loadChildren: () =>
      import('./pages/popup4/popup4.module').then((m) => m.Popup4Module),
  },
  {
    path: 'pensioner5',
    loadChildren: () =>
      import('./pages/pensioner5/pensioner5.module').then(
        (m) => m.Pensioner5Module
      ),
  },
  {
    path: 'pensioner-profile2',
    loadChildren: () =>
      import('./pages/pensioner-profile2/pensioner-profile2.module').then(
        (m) => m.PensionerProfile2Module
      ),
  },
  {
    path: 'live-stats2',
    loadChildren: () =>
      import('./pages/live-stats2/live-stats2.module').then(
        (m) => m.LiveStats2Module
      ),
  },
  {
    path: 'pensioner4',
    loadChildren: () =>
      import('./pages/pensioner4/pensioner4.module').then(
        (m) => m.Pensioner4Module
      ),
  },
  {
    path: 'chief-probation12',
    loadChildren: () =>
      import('./pages/chief-probation12/chief-probation12.module').then(
        (m) => m.ChiefProbation12Module
      ),
  },
  {
    path: 'account-pending1',
    loadChildren: () =>
      import('./pages/account-pending1/account-pending1.module').then(
        (m) => m.AccountPending1Module
      ),
  },
  {
    path: 'account-pending2',
    loadChildren: () =>
      import('./pages/account-pending2/account-pending2.module').then(
        (m) => m.AccountPending2Module
      ),
  },
  {
    path: 'log-in2',
    loadChildren: () =>
      import('./pages/log-in2/log-in2.module').then((m) => m.LogIn2Module),
  },
  {
    path: 'merchant2',
    loadChildren: () =>
      import('./pages/merchant2/merchant2.module').then(
        (m) => m.Merchant2Module
      ),
  },
  {
    path: 'popup',
    loadChildren: () =>
      import('./pages/popup/popup.module').then((m) => m.PopupModule),
  },
  {
    path: 'popup11',
    loadChildren: () =>
      import('./pages/popup11/popup11.module').then((m) => m.Popup11Module),
  },
  {
    path: 'popup9',
    loadChildren: () =>
      import('./pages/popup9/popup9.module').then((m) => m.Popup9Module),
  },
  {
    path: 'beneficiary13',
    loadChildren: () =>
      import('./pages/beneficiary13/beneficiary13.module').then(
        (m) => m.Beneficiary13Module
      ),
  },
  {
    path: 'pensioner3',
    loadChildren: () =>
      import('./pages/pensioner3/pensioner3.module').then(
        (m) => m.Pensioner3Module
      ),
  },
  {
    path: 'beneficiary10',
    loadChildren: () =>
      import('./pages/beneficiary10/beneficiary10.module').then(
        (m) => m.Beneficiary10Module
      ),
  },
  {
    path: 'employee31',
    loadChildren: () =>
      import('./pages/employee31/employee31.module').then(
        (m) => m.Employee31Module
      ),
  },
  {
    path: 'beneficiary2',
    loadChildren: () =>
      import('./pages/beneficiary2/beneficiary2.module').then(
        (m) => m.Beneficiary2Module
      ),
  },
  {
    path: 'beneficiary131',
    loadChildren: () =>
      import('./pages/beneficiary131/beneficiary131.module').then(
        (m) => m.Beneficiary131Module
      ),
  },
  {
    path: 'register1',
    loadChildren: () =>
      import('./pages/register1/register1.module').then(
        (m) => m.Register1Module
      ),
  },
  {
    path: 'live-stats1',
    loadChildren: () =>
      import('./pages/live-stats1/live-stats1.module').then(
        (m) => m.LiveStats1Module
      ),
  },
  {
    path: 'pensioner8',
    loadChildren: () =>
      import('./pages/pensioner8/pensioner8.module').then(
        (m) => m.Pensioner8Module
      ),
  },
  {
    path: 'application1',
    loadChildren: () =>
      import('./pages/application1/application1.module').then(
        (m) => m.Application1Module
      ),
  },
  {
    path: 'beneficiary6',
    loadChildren: () =>
      import('./pages/beneficiary6/beneficiary6.module').then(
        (m) => m.Beneficiary6Module
      ),
  },
  {
    path: 'receiving-officer2',
    loadChildren: () =>
      import('./pages/receiving-officer2/receiving-officer2.module').then(
        (m) => m.ReceivingOfficer2Module
      ),
  },
  {
    path: 'beneficiary4',
    loadChildren: () =>
      import('./pages/beneficiary4/beneficiary4.module').then(
        (m) => m.Beneficiary4Module
      ),
  },
  {
    path: 'social-worker1',
    loadChildren: () =>
      import('./pages/social-worker1/social-worker1.module').then(
        (m) => m.SocialWorker1Module
      ),
  },
  {
    path: 'popup10',
    loadChildren: () =>
      import('./pages/popup10/popup10.module').then((m) => m.Popup10Module),
  },
  {
    path: 'pensioner1',
    loadChildren: () =>
      import('./pages/pensioner1/pensioner1.module').then(
        (m) => m.Pensioner1Module
      ),
  },
  {
    path: 'beneficiary7',
    loadChildren: () =>
      import('./pages/beneficiary7/beneficiary7.module').then(
        (m) => m.Beneficiary7Module
      ),
  },
  {
    path: 'accounts1',
    loadChildren: () =>
      import('./pages/accounts1/accounts1.module').then(
        (m) => m.Accounts1Module
      ),
  },
  {
    path: 'social-worker11',
    loadChildren: () =>
      import('./pages/social-worker11/social-worker11.module').then(
        (m) => m.SocialWorker11Module
      ),
  },
  {
    path: 'register2',
    loadChildren: () =>
      import('./pages/register2/register2.module').then(
        (m) => m.Register2Module
      ),
  },
  {
    path: 'pensioner-home2',
    loadChildren: () =>
      import('./pages/pensioner-home2/pensioner-home2.module').then(
        (m) => m.PensionerHome2Module
      ),
  },
  {
    path: 'popup7',
    loadChildren: () =>
      import('./pages/popup7/popup7.module').then((m) => m.Popup7Module),
  },
  {
    path: 'employee111',
    loadChildren: () =>
      import('./pages/employee111/employee111.module').then(
        (m) => m.Employee111Module
      ),
  },
  {
    path: 'beneficiary111',
    loadChildren: () =>
      import('./pages/beneficiary111/beneficiary111.module').then(
        (m) => m.Beneficiary111Module
      ),
  },
  {
    path: 'application-status2',
    loadChildren: () =>
      import('./pages/application-status2/application-status2.module').then(
        (m) => m.ApplicationStatus2Module
      ),
  },
  {
    path: 'employee-home',
    loadChildren: () =>
      import('./pages/employee-home/employee-home.module').then(
        (m) => m.EmployeeHomeModule
      ),
  },
  {
    path: 'employee2',
    loadChildren: () =>
      import('./pages/employee2/employee2.module').then(
        (m) => m.Employee2Module
      ),
  },
  {
    path: 'merchant-home',
    loadChildren: () =>
      import('./pages/merchant-home/merchant-home.module').then(
        (m) => m.MerchantHomeModule
      ),
  },
  {
    path: 'notifications',
    loadChildren: () =>
      import('./pages/notifications/notifications.module').then(
        (m) => m.NotificationsModule
      ),
  },
  {
    path: 'chief-probation2',
    loadChildren: () =>
      import('./pages/chief-probation2/chief-probation2.module').then(
        (m) => m.ChiefProbation2Module
      ),
  },
  {
    path: 'live-stats3',
    loadChildren: () =>
      import('./pages/live-stats3/live-stats3.module').then(
        (m) => m.LiveStats3Module
      ),
  },
  {
    path: 'merchant4',
    loadChildren: () =>
      import('./pages/merchant4/merchant4.module').then(
        (m) => m.Merchant4Module
      ),
  },
  {
    path: 'popup5',
    loadChildren: () =>
      import('./pages/popup5/popup5.module').then((m) => m.Popup5Module),
  },
  {
    path: 'employee21',
    loadChildren: () =>
      import('./pages/employee21/employee21.module').then(
        (m) => m.Employee21Module
      ),
  },
  {
    path: 'merchant-home1',
    loadChildren: () =>
      import('./pages/merchant-home1/merchant-home1.module').then(
        (m) => m.MerchantHome1Module
      ),
  },
  {
    path: 'application5',
    loadChildren: () =>
      import('./pages/application5/application5.module').then(
        (m) => m.Application5Module
      ),
  },
  {
    path: 'g-r-o2',
    loadChildren: () =>
      import('./pages/g-r-o2/g-r-o2.module').then((m) => m.GRO2Module),
  },
  {
    path: 'beneficiary1',
    loadChildren: () =>
      import('./pages/beneficiary1/beneficiary1.module').then(
        (m) => m.Beneficiary1Module
      ),
  },
  {
    path: 'popup2',
    loadChildren: () =>
      import('./pages/popup2/popup2.module').then((m) => m.Popup2Module),
  },
  {
    path: 'beneficiary121',
    loadChildren: () =>
      import('./pages/beneficiary121/beneficiary121.module').then(
        (m) => m.Beneficiary121Module
      ),
  },
  {
    path: 'merchants',
    loadChildren: () =>
      import('./pages/merchants/merchants.module').then(
        (m) => m.MerchantsModule
      ),
  },
  {
    path: 'employee4',
    loadChildren: () =>
      import('./pages/employee4/employee4.module').then(
        (m) => m.Employee4Module
      ),
  },
  {
    path: 'launch',
    loadChildren: () =>
      import('./pages/launch/launch.module').then((m) => m.LaunchModule),
  },
  {
    path: 'merchant5',
    loadChildren: () =>
      import('./pages/merchant5/merchant5.module').then(
        (m) => m.Merchant5Module
      ),
  },
  {
    path: 'popup8',
    loadChildren: () =>
      import('./pages/popup8/popup8.module').then((m) => m.Popup8Module),
  },
  {
    path: 'popup1',
    loadChildren: () =>
      import('./pages/popup1/popup1.module').then((m) => m.Popup1Module),
  },
]

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, RouterModule.forRoot(routes), ComponentsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
