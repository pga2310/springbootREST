import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { MerchantHome1 } from './merchant-home1.component'

const routes = [
  {
    path: '',
    component: MerchantHome1,
  },
]

@NgModule({
  declarations: [MerchantHome1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [MerchantHome1],
})
export class MerchantHome1Module {}
