import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'merchant-home1',
  templateUrl: 'merchant-home1.component.html',
  styleUrls: ['merchant-home1.component.css'],
})
export class MerchantHome1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
