import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Application3 } from './application3.component'

const routes = [
  {
    path: '',
    component: Application3,
  },
]

@NgModule({
  declarations: [Application3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Application3],
})
export class Application3Module {}
