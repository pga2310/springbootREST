import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-application3',
  templateUrl: 'application3.component.html',
  styleUrls: ['application3.component.css'],
})
export class Application3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
