import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { SocialWorker4 } from './social-worker4.component'

const routes = [
  {
    path: '',
    component: SocialWorker4,
  },
]

@NgModule({
  declarations: [SocialWorker4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [SocialWorker4],
})
export class SocialWorker4Module {}
