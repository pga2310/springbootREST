import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary9',
  templateUrl: 'beneficiary9.component.html',
  styleUrls: ['beneficiary9.component.css'],
})
export class Beneficiary9 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
