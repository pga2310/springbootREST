import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary9 } from './beneficiary9.component'

const routes = [
  {
    path: '',
    component: Beneficiary9,
  },
]

@NgModule({
  declarations: [Beneficiary9],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary9],
})
export class Beneficiary9Module {}
