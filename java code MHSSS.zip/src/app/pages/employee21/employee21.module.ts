import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee21 } from './employee21.component'

const routes = [
  {
    path: '',
    component: Employee21,
  },
]

@NgModule({
  declarations: [Employee21],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee21],
})
export class Employee21Module {}
