import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee21',
  templateUrl: 'employee21.component.html',
  styleUrls: ['employee21.component.css'],
})
export class Employee21 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
