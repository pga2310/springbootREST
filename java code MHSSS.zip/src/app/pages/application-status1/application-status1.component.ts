import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'application-status1',
  templateUrl: 'application-status1.component.html',
  styleUrls: ['application-status1.component.css'],
})
export class ApplicationStatus1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
