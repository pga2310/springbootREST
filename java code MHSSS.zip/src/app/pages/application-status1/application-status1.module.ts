import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ApplicationStatus1 } from './application-status1.component'

const routes = [
  {
    path: '',
    component: ApplicationStatus1,
  },
]

@NgModule({
  declarations: [ApplicationStatus1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ApplicationStatus1],
})
export class ApplicationStatus1Module {}
