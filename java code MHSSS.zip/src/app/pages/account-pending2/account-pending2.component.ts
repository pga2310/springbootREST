import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'account-pending2',
  templateUrl: 'account-pending2.component.html',
  styleUrls: ['account-pending2.component.css'],
})
export class AccountPending2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
