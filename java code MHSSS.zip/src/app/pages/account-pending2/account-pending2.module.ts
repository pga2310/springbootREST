import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { AccountPending2 } from './account-pending2.component'

const routes = [
  {
    path: '',
    component: AccountPending2,
  },
]

@NgModule({
  declarations: [AccountPending2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [AccountPending2],
})
export class AccountPending2Module {}
