import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'live-stats4',
  templateUrl: 'live-stats4.component.html',
  styleUrls: ['live-stats4.component.css'],
})
export class LiveStats4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
