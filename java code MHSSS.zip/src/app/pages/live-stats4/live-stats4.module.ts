import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { LiveStats4 } from './live-stats4.component'

const routes = [
  {
    path: '',
    component: LiveStats4,
  },
]

@NgModule({
  declarations: [LiveStats4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [LiveStats4],
})
export class LiveStats4Module {}
