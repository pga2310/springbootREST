import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup4 } from './popup4.component'

const routes = [
  {
    path: '',
    component: Popup4,
  },
]

@NgModule({
  declarations: [Popup4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup4],
})
export class Popup4Module {}
