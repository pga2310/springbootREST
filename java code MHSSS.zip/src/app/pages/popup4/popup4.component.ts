import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup4',
  templateUrl: 'popup4.component.html',
  styleUrls: ['popup4.component.css'],
})
export class Popup4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
