import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup11',
  templateUrl: 'popup11.component.html',
  styleUrls: ['popup11.component.css'],
})
export class Popup11 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
