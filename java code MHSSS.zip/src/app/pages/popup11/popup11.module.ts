import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup11 } from './popup11.component'

const routes = [
  {
    path: '',
    component: Popup11,
  },
]

@NgModule({
  declarations: [Popup11],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup11],
})
export class Popup11Module {}
