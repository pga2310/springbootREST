import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'chief-probation12',
  templateUrl: 'chief-probation12.component.html',
  styleUrls: ['chief-probation12.component.css'],
})
export class ChiefProbation12 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
