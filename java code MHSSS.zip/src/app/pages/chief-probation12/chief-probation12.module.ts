import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ChiefProbation12 } from './chief-probation12.component'

const routes = [
  {
    path: '',
    component: ChiefProbation12,
  },
]

@NgModule({
  declarations: [ChiefProbation12],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ChiefProbation12],
})
export class ChiefProbation12Module {}
