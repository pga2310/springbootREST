import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee7 } from './employee7.component'

const routes = [
  {
    path: '',
    component: Employee7,
  },
]

@NgModule({
  declarations: [Employee7],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee7],
})
export class Employee7Module {}
