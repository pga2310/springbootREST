import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee7',
  templateUrl: 'employee7.component.html',
  styleUrls: ['employee7.component.css'],
})
export class Employee7 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
