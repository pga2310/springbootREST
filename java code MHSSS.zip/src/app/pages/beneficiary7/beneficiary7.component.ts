import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary7',
  templateUrl: 'beneficiary7.component.html',
  styleUrls: ['beneficiary7.component.css'],
})
export class Beneficiary7 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
