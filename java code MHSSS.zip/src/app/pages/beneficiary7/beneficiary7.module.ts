import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary7 } from './beneficiary7.component'

const routes = [
  {
    path: '',
    component: Beneficiary7,
  },
]

@NgModule({
  declarations: [Beneficiary7],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary7],
})
export class Beneficiary7Module {}
