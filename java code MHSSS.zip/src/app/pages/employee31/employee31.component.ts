import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee31',
  templateUrl: 'employee31.component.html',
  styleUrls: ['employee31.component.css'],
})
export class Employee31 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
