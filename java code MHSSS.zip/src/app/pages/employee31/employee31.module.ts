import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee31 } from './employee31.component'

const routes = [
  {
    path: '',
    component: Employee31,
  },
]

@NgModule({
  declarations: [Employee31],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee31],
})
export class Employee31Module {}
