import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ReceivingOfficer2 } from './receiving-officer2.component'

const routes = [
  {
    path: '',
    component: ReceivingOfficer2,
  },
]

@NgModule({
  declarations: [ReceivingOfficer2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ReceivingOfficer2],
})
export class ReceivingOfficer2Module {}
