import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'receiving-officer2',
  templateUrl: 'receiving-officer2.component.html',
  styleUrls: ['receiving-officer2.component.css'],
})
export class ReceivingOfficer2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
