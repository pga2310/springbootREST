import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'chief-probation2',
  templateUrl: 'chief-probation2.component.html',
  styleUrls: ['chief-probation2.component.css'],
})
export class ChiefProbation2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
