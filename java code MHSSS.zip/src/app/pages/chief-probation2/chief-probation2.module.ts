import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ChiefProbation2 } from './chief-probation2.component'

const routes = [
  {
    path: '',
    component: ChiefProbation2,
  },
]

@NgModule({
  declarations: [ChiefProbation2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ChiefProbation2],
})
export class ChiefProbation2Module {}
