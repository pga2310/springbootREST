import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary12 } from './beneficiary12.component'

const routes = [
  {
    path: '',
    component: Beneficiary12,
  },
]

@NgModule({
  declarations: [Beneficiary12],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary12],
})
export class Beneficiary12Module {}
