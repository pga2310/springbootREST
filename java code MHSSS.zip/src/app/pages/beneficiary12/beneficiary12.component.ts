import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary12',
  templateUrl: 'beneficiary12.component.html',
  styleUrls: ['beneficiary12.component.css'],
})
export class Beneficiary12 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
