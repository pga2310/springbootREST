import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee2 } from './employee2.component'

const routes = [
  {
    path: '',
    component: Employee2,
  },
]

@NgModule({
  declarations: [Employee2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee2],
})
export class Employee2Module {}
