import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee2',
  templateUrl: 'employee2.component.html',
  styleUrls: ['employee2.component.css'],
})
export class Employee2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
