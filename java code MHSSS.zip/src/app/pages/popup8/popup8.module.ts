import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup8 } from './popup8.component'

const routes = [
  {
    path: '',
    component: Popup8,
  },
]

@NgModule({
  declarations: [Popup8],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup8],
})
export class Popup8Module {}
