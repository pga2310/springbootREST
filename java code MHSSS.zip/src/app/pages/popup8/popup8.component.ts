import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup8',
  templateUrl: 'popup8.component.html',
  styleUrls: ['popup8.component.css'],
})
export class Popup8 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
