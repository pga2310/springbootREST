import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee3',
  templateUrl: 'employee3.component.html',
  styleUrls: ['employee3.component.css'],
})
export class Employee3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
