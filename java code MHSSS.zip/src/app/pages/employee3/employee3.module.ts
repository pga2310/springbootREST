import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee3 } from './employee3.component'

const routes = [
  {
    path: '',
    component: Employee3,
  },
]

@NgModule({
  declarations: [Employee3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee3],
})
export class Employee3Module {}
