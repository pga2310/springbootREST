import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Register1 } from './register1.component'

const routes = [
  {
    path: '',
    component: Register1,
  },
]

@NgModule({
  declarations: [Register1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Register1],
})
export class Register1Module {}
