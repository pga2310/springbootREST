import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup } from './popup.component'

const routes = [
  {
    path: '',
    component: Popup,
  },
]

@NgModule({
  declarations: [Popup],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup],
})
export class PopupModule {}
