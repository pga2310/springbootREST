import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { PensionerHome1 } from './pensioner-home1.component'

const routes = [
  {
    path: '',
    component: PensionerHome1,
  },
]

@NgModule({
  declarations: [PensionerHome1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [PensionerHome1],
})
export class PensionerHome1Module {}
