import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'pensioner-home1',
  templateUrl: 'pensioner-home1.component.html',
  styleUrls: ['pensioner-home1.component.css'],
})
export class PensionerHome1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
