import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'g-r-o1',
  templateUrl: 'g-r-o1.component.html',
  styleUrls: ['g-r-o1.component.css'],
})
export class GRO1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
