import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { GRO1 } from './g-r-o1.component'

const routes = [
  {
    path: '',
    component: GRO1,
  },
]

@NgModule({
  declarations: [GRO1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [GRO1],
})
export class GRO1Module {}
