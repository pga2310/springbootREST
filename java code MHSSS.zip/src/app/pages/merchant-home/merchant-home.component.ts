import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'merchant-home',
  templateUrl: 'merchant-home.component.html',
  styleUrls: ['merchant-home.component.css'],
})
export class MerchantHome {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
