import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { MerchantHome } from './merchant-home.component'

const routes = [
  {
    path: '',
    component: MerchantHome,
  },
]

@NgModule({
  declarations: [MerchantHome],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [MerchantHome],
})
export class MerchantHomeModule {}
