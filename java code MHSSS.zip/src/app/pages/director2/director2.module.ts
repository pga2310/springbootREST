import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Director2 } from './director2.component'

const routes = [
  {
    path: '',
    component: Director2,
  },
]

@NgModule({
  declarations: [Director2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Director2],
})
export class Director2Module {}
