import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-director2',
  templateUrl: 'director2.component.html',
  styleUrls: ['director2.component.css'],
})
export class Director2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
