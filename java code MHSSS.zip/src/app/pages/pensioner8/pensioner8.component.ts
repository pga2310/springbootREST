import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-pensioner8',
  templateUrl: 'pensioner8.component.html',
  styleUrls: ['pensioner8.component.css'],
})
export class Pensioner8 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
