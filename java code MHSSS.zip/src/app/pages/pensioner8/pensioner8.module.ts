import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner8 } from './pensioner8.component'

const routes = [
  {
    path: '',
    component: Pensioner8,
  },
]

@NgModule({
  declarations: [Pensioner8],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner8],
})
export class Pensioner8Module {}
