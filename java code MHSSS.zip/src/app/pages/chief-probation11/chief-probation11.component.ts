import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'chief-probation11',
  templateUrl: 'chief-probation11.component.html',
  styleUrls: ['chief-probation11.component.css'],
})
export class ChiefProbation11 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
