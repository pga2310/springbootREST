import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ChiefProbation11 } from './chief-probation11.component'

const routes = [
  {
    path: '',
    component: ChiefProbation11,
  },
]

@NgModule({
  declarations: [ChiefProbation11],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ChiefProbation11],
})
export class ChiefProbation11Module {}
