import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'application-status2',
  templateUrl: 'application-status2.component.html',
  styleUrls: ['application-status2.component.css'],
})
export class ApplicationStatus2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
