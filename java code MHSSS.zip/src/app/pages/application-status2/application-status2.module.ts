import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ApplicationStatus2 } from './application-status2.component'

const routes = [
  {
    path: '',
    component: ApplicationStatus2,
  },
]

@NgModule({
  declarations: [ApplicationStatus2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ApplicationStatus2],
})
export class ApplicationStatus2Module {}
