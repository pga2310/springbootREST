import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { AccountPending1 } from './account-pending1.component'

const routes = [
  {
    path: '',
    component: AccountPending1,
  },
]

@NgModule({
  declarations: [AccountPending1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [AccountPending1],
})
export class AccountPending1Module {}
