import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'account-pending1',
  templateUrl: 'account-pending1.component.html',
  styleUrls: ['account-pending1.component.css'],
})
export class AccountPending1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
