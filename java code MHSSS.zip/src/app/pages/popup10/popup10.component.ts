import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup10',
  templateUrl: 'popup10.component.html',
  styleUrls: ['popup10.component.css'],
})
export class Popup10 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
