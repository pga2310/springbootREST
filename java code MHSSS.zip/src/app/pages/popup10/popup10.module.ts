import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup10 } from './popup10.component'

const routes = [
  {
    path: '',
    component: Popup10,
  },
]

@NgModule({
  declarations: [Popup10],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup10],
})
export class Popup10Module {}
