import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'merchant-home2',
  templateUrl: 'merchant-home2.component.html',
  styleUrls: ['merchant-home2.component.css'],
})
export class MerchantHome2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
