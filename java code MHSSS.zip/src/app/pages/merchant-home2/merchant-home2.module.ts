import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { MerchantHome2 } from './merchant-home2.component'

const routes = [
  {
    path: '',
    component: MerchantHome2,
  },
]

@NgModule({
  declarations: [MerchantHome2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [MerchantHome2],
})
export class MerchantHome2Module {}
