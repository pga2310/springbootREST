import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup5',
  templateUrl: 'popup5.component.html',
  styleUrls: ['popup5.component.css'],
})
export class Popup5 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
