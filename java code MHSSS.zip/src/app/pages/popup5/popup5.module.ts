import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup5 } from './popup5.component'

const routes = [
  {
    path: '',
    component: Popup5,
  },
]

@NgModule({
  declarations: [Popup5],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup5],
})
export class Popup5Module {}
