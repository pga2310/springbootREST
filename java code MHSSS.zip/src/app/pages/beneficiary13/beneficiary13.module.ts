import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary13 } from './beneficiary13.component'

const routes = [
  {
    path: '',
    component: Beneficiary13,
  },
]

@NgModule({
  declarations: [Beneficiary13],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary13],
})
export class Beneficiary13Module {}
