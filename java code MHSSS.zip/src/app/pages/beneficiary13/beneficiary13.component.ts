import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary13',
  templateUrl: 'beneficiary13.component.html',
  styleUrls: ['beneficiary13.component.css'],
})
export class Beneficiary13 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
