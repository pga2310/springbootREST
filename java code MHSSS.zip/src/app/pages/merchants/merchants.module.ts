import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Merchants } from './merchants.component'

const routes = [
  {
    path: '',
    component: Merchants,
  },
]

@NgModule({
  declarations: [Merchants],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Merchants],
})
export class MerchantsModule {}
