import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-merchants',
  templateUrl: 'merchants.component.html',
  styleUrls: ['merchants.component.css'],
})
export class Merchants {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
