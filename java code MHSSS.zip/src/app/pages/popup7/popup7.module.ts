import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup7 } from './popup7.component'

const routes = [
  {
    path: '',
    component: Popup7,
  },
]

@NgModule({
  declarations: [Popup7],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup7],
})
export class Popup7Module {}
