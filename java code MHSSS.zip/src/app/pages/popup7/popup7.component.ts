import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup7',
  templateUrl: 'popup7.component.html',
  styleUrls: ['popup7.component.css'],
})
export class Popup7 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
