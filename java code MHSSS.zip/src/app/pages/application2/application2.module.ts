import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Application2 } from './application2.component'

const routes = [
  {
    path: '',
    component: Application2,
  },
]

@NgModule({
  declarations: [Application2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Application2],
})
export class Application2Module {}
