import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-application2',
  templateUrl: 'application2.component.html',
  styleUrls: ['application2.component.css'],
})
export class Application2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
