import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-notifications',
  templateUrl: 'notifications.component.html',
  styleUrls: ['notifications.component.css'],
})
export class Notifications {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
