import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary10 } from './beneficiary10.component'

const routes = [
  {
    path: '',
    component: Beneficiary10,
  },
]

@NgModule({
  declarations: [Beneficiary10],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary10],
})
export class Beneficiary10Module {}
