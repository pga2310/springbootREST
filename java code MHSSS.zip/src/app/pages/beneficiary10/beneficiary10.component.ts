import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary10',
  templateUrl: 'beneficiary10.component.html',
  styleUrls: ['beneficiary10.component.css'],
})
export class Beneficiary10 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
