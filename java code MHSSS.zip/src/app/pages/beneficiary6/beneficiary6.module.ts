import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary6 } from './beneficiary6.component'

const routes = [
  {
    path: '',
    component: Beneficiary6,
  },
]

@NgModule({
  declarations: [Beneficiary6],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary6],
})
export class Beneficiary6Module {}
