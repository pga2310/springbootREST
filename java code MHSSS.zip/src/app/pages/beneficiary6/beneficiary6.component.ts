import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary6',
  templateUrl: 'beneficiary6.component.html',
  styleUrls: ['beneficiary6.component.css'],
})
export class Beneficiary6 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
