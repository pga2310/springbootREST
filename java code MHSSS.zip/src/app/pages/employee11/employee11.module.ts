import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee11 } from './employee11.component'

const routes = [
  {
    path: '',
    component: Employee11,
  },
]

@NgModule({
  declarations: [Employee11],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee11],
})
export class Employee11Module {}
