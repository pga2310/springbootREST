import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee11',
  templateUrl: 'employee11.component.html',
  styleUrls: ['employee11.component.css'],
})
export class Employee11 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
