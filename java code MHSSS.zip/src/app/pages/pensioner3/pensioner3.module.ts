import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner3 } from './pensioner3.component'

const routes = [
  {
    path: '',
    component: Pensioner3,
  },
]

@NgModule({
  declarations: [Pensioner3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner3],
})
export class Pensioner3Module {}
