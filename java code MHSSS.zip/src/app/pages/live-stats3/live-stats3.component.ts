import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'live-stats3',
  templateUrl: 'live-stats3.component.html',
  styleUrls: ['live-stats3.component.css'],
})
export class LiveStats3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
