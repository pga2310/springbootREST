import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { LiveStats3 } from './live-stats3.component'

const routes = [
  {
    path: '',
    component: LiveStats3,
  },
]

@NgModule({
  declarations: [LiveStats3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [LiveStats3],
})
export class LiveStats3Module {}
