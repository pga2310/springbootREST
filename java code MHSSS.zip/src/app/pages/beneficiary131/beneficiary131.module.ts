import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary131 } from './beneficiary131.component'

const routes = [
  {
    path: '',
    component: Beneficiary131,
  },
]

@NgModule({
  declarations: [Beneficiary131],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary131],
})
export class Beneficiary131Module {}
