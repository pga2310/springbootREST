import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary131',
  templateUrl: 'beneficiary131.component.html',
  styleUrls: ['beneficiary131.component.css'],
})
export class Beneficiary131 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
