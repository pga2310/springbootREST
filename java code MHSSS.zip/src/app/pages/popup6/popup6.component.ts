import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup6',
  templateUrl: 'popup6.component.html',
  styleUrls: ['popup6.component.css'],
})
export class Popup6 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
