import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup6 } from './popup6.component'

const routes = [
  {
    path: '',
    component: Popup6,
  },
]

@NgModule({
  declarations: [Popup6],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup6],
})
export class Popup6Module {}
