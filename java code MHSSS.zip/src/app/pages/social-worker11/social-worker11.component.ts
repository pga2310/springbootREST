import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'social-worker11',
  templateUrl: 'social-worker11.component.html',
  styleUrls: ['social-worker11.component.css'],
})
export class SocialWorker11 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
