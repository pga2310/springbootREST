import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { SocialWorker11 } from './social-worker11.component'

const routes = [
  {
    path: '',
    component: SocialWorker11,
  },
]

@NgModule({
  declarations: [SocialWorker11],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [SocialWorker11],
})
export class SocialWorker11Module {}
