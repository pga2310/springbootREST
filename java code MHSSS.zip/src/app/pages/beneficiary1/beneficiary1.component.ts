import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary1',
  templateUrl: 'beneficiary1.component.html',
  styleUrls: ['beneficiary1.component.css'],
})
export class Beneficiary1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
