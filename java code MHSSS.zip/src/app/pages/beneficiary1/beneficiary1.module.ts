import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary1 } from './beneficiary1.component'

const routes = [
  {
    path: '',
    component: Beneficiary1,
  },
]

@NgModule({
  declarations: [Beneficiary1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary1],
})
export class Beneficiary1Module {}
