import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup2',
  templateUrl: 'popup2.component.html',
  styleUrls: ['popup2.component.css'],
})
export class Popup2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
