import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup2 } from './popup2.component'

const routes = [
  {
    path: '',
    component: Popup2,
  },
]

@NgModule({
  declarations: [Popup2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup2],
})
export class Popup2Module {}
