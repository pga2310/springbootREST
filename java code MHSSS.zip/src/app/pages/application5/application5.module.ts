import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Application5 } from './application5.component'

const routes = [
  {
    path: '',
    component: Application5,
  },
]

@NgModule({
  declarations: [Application5],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Application5],
})
export class Application5Module {}
