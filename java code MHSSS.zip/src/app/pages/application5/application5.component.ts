import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-application5',
  templateUrl: 'application5.component.html',
  styleUrls: ['application5.component.css'],
})
export class Application5 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
