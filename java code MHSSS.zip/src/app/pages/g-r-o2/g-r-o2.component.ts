import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'g-r-o2',
  templateUrl: 'g-r-o2.component.html',
  styleUrls: ['g-r-o2.component.css'],
})
export class GRO2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
