import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { GRO2 } from './g-r-o2.component'

const routes = [
  {
    path: '',
    component: GRO2,
  },
]

@NgModule({
  declarations: [GRO2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [GRO2],
})
export class GRO2Module {}
