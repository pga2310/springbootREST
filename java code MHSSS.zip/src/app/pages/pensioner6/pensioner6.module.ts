import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner6 } from './pensioner6.component'

const routes = [
  {
    path: '',
    component: Pensioner6,
  },
]

@NgModule({
  declarations: [Pensioner6],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner6],
})
export class Pensioner6Module {}
