import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee6 } from './employee6.component'

const routes = [
  {
    path: '',
    component: Employee6,
  },
]

@NgModule({
  declarations: [Employee6],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee6],
})
export class Employee6Module {}
