import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee6',
  templateUrl: 'employee6.component.html',
  styleUrls: ['employee6.component.css'],
})
export class Employee6 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
