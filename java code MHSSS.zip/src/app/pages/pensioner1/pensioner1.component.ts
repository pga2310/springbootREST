import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-pensioner1',
  templateUrl: 'pensioner1.component.html',
  styleUrls: ['pensioner1.component.css'],
})
export class Pensioner1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
