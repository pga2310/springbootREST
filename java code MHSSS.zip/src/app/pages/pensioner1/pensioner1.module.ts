import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner1 } from './pensioner1.component'

const routes = [
  {
    path: '',
    component: Pensioner1,
  },
]

@NgModule({
  declarations: [Pensioner1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner1],
})
export class Pensioner1Module {}
