import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'live-stats2',
  templateUrl: 'live-stats2.component.html',
  styleUrls: ['live-stats2.component.css'],
})
export class LiveStats2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
