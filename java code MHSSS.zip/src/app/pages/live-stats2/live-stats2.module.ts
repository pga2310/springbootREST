import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { LiveStats2 } from './live-stats2.component'

const routes = [
  {
    path: '',
    component: LiveStats2,
  },
]

@NgModule({
  declarations: [LiveStats2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [LiveStats2],
})
export class LiveStats2Module {}
