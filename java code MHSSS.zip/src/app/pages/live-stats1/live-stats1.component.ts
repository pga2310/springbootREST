import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'live-stats1',
  templateUrl: 'live-stats1.component.html',
  styleUrls: ['live-stats1.component.css'],
})
export class LiveStats1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
