import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { LiveStats1 } from './live-stats1.component'

const routes = [
  {
    path: '',
    component: LiveStats1,
  },
]

@NgModule({
  declarations: [LiveStats1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [LiveStats1],
})
export class LiveStats1Module {}
