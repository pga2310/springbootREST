import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee111 } from './employee111.component'

const routes = [
  {
    path: '',
    component: Employee111,
  },
]

@NgModule({
  declarations: [Employee111],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee111],
})
export class Employee111Module {}
