import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee111',
  templateUrl: 'employee111.component.html',
  styleUrls: ['employee111.component.css'],
})
export class Employee111 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
