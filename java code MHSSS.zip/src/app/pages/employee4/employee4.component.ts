import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee4',
  templateUrl: 'employee4.component.html',
  styleUrls: ['employee4.component.css'],
})
export class Employee4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
