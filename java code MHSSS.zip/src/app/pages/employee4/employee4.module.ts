import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee4 } from './employee4.component'

const routes = [
  {
    path: '',
    component: Employee4,
  },
]

@NgModule({
  declarations: [Employee4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee4],
})
export class Employee4Module {}
