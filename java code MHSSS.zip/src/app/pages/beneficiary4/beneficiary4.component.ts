import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary4',
  templateUrl: 'beneficiary4.component.html',
  styleUrls: ['beneficiary4.component.css'],
})
export class Beneficiary4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
