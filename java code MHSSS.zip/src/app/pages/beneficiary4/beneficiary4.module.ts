import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary4 } from './beneficiary4.component'

const routes = [
  {
    path: '',
    component: Beneficiary4,
  },
]

@NgModule({
  declarations: [Beneficiary4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary4],
})
export class Beneficiary4Module {}
