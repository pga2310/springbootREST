import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'pensioner-home2',
  templateUrl: 'pensioner-home2.component.html',
  styleUrls: ['pensioner-home2.component.css'],
})
export class PensionerHome2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
