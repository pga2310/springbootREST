import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { PensionerHome2 } from './pensioner-home2.component'

const routes = [
  {
    path: '',
    component: PensionerHome2,
  },
]

@NgModule({
  declarations: [PensionerHome2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [PensionerHome2],
})
export class PensionerHome2Module {}
