import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup1 } from './popup1.component'

const routes = [
  {
    path: '',
    component: Popup1,
  },
]

@NgModule({
  declarations: [Popup1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup1],
})
export class Popup1Module {}
