import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup1',
  templateUrl: 'popup1.component.html',
  styleUrls: ['popup1.component.css'],
})
export class Popup1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
