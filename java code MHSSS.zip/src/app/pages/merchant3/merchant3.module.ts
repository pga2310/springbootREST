import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Merchant3 } from './merchant3.component'

const routes = [
  {
    path: '',
    component: Merchant3,
  },
]

@NgModule({
  declarations: [Merchant3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Merchant3],
})
export class Merchant3Module {}
