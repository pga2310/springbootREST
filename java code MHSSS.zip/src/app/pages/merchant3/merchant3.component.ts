import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-merchant3',
  templateUrl: 'merchant3.component.html',
  styleUrls: ['merchant3.component.css'],
})
export class Merchant3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
