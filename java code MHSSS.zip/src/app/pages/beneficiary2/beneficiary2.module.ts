import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary2 } from './beneficiary2.component'

const routes = [
  {
    path: '',
    component: Beneficiary2,
  },
]

@NgModule({
  declarations: [Beneficiary2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary2],
})
export class Beneficiary2Module {}
