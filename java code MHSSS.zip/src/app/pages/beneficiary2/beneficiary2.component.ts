import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary2',
  templateUrl: 'beneficiary2.component.html',
  styleUrls: ['beneficiary2.component.css'],
})
export class Beneficiary2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
