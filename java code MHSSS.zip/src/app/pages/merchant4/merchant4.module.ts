import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Merchant4 } from './merchant4.component'

const routes = [
  {
    path: '',
    component: Merchant4,
  },
]

@NgModule({
  declarations: [Merchant4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Merchant4],
})
export class Merchant4Module {}
