import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-merchant4',
  templateUrl: 'merchant4.component.html',
  styleUrls: ['merchant4.component.css'],
})
export class Merchant4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
