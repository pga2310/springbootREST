import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ChiefProbation1 } from './chief-probation1.component'

const routes = [
  {
    path: '',
    component: ChiefProbation1,
  },
]

@NgModule({
  declarations: [ChiefProbation1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ChiefProbation1],
})
export class ChiefProbation1Module {}
