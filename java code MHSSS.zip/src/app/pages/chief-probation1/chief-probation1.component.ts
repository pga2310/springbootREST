import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'chief-probation1',
  templateUrl: 'chief-probation1.component.html',
  styleUrls: ['chief-probation1.component.css'],
})
export class ChiefProbation1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
