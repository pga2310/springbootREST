import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Accounts2 } from './accounts2.component'

const routes = [
  {
    path: '',
    component: Accounts2,
  },
]

@NgModule({
  declarations: [Accounts2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Accounts2],
})
export class Accounts2Module {}
