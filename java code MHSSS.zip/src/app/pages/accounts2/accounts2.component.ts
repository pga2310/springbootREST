import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-accounts2',
  templateUrl: 'accounts2.component.html',
  styleUrls: ['accounts2.component.css'],
})
export class Accounts2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
