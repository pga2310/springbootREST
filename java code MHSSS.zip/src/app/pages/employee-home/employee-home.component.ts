import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'employee-home',
  templateUrl: 'employee-home.component.html',
  styleUrls: ['employee-home.component.css'],
})
export class EmployeeHome {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
