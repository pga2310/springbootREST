import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { EmployeeHome } from './employee-home.component'

const routes = [
  {
    path: '',
    component: EmployeeHome,
  },
]

@NgModule({
  declarations: [EmployeeHome],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [EmployeeHome],
})
export class EmployeeHomeModule {}
