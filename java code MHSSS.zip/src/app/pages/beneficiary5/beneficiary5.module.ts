import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary5 } from './beneficiary5.component'

const routes = [
  {
    path: '',
    component: Beneficiary5,
  },
]

@NgModule({
  declarations: [Beneficiary5],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary5],
})
export class Beneficiary5Module {}
