import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary5',
  templateUrl: 'beneficiary5.component.html',
  styleUrls: ['beneficiary5.component.css'],
})
export class Beneficiary5 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
