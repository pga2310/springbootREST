import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup3',
  templateUrl: 'popup3.component.html',
  styleUrls: ['popup3.component.css'],
})
export class Popup3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
