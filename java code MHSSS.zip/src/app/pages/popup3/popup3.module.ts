import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup3 } from './popup3.component'

const routes = [
  {
    path: '',
    component: Popup3,
  },
]

@NgModule({
  declarations: [Popup3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup3],
})
export class Popup3Module {}
