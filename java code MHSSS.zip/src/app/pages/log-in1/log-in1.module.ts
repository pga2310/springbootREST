import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { LogIn1 } from './log-in1.component'

const routes = [
  {
    path: '',
    component: LogIn1,
  },
]

@NgModule({
  declarations: [LogIn1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [LogIn1],
})
export class LogIn1Module {}
