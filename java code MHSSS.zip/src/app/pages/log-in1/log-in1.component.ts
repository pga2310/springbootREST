import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'log-in1',
  templateUrl: 'log-in1.component.html',
  styleUrls: ['log-in1.component.css'],
})
export class LogIn1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
