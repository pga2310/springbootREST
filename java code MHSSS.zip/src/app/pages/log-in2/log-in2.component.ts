import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'log-in2',
  templateUrl: 'log-in2.component.html',
  styleUrls: ['log-in2.component.css'],
})
export class LogIn2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
