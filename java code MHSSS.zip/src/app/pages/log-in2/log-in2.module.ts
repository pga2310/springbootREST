import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { LogIn2 } from './log-in2.component'

const routes = [
  {
    path: '',
    component: LogIn2,
  },
]

@NgModule({
  declarations: [LogIn2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [LogIn2],
})
export class LogIn2Module {}
