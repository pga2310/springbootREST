import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary8',
  templateUrl: 'beneficiary8.component.html',
  styleUrls: ['beneficiary8.component.css'],
})
export class Beneficiary8 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
