import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary8 } from './beneficiary8.component'

const routes = [
  {
    path: '',
    component: Beneficiary8,
  },
]

@NgModule({
  declarations: [Beneficiary8],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary8],
})
export class Beneficiary8Module {}
