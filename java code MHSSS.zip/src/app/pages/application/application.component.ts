import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-application',
  templateUrl: 'application.component.html',
  styleUrls: ['application.component.css'],
})
export class Application {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
