import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { AccountPending } from './account-pending.component'

const routes = [
  {
    path: '',
    component: AccountPending,
  },
]

@NgModule({
  declarations: [AccountPending],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [AccountPending],
})
export class AccountPendingModule {}
