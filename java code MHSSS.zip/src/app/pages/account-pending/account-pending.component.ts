import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'account-pending',
  templateUrl: 'account-pending.component.html',
  styleUrls: ['account-pending.component.css'],
})
export class AccountPending {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
