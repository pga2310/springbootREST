import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Launch } from './launch.component'

const routes = [
  {
    path: '',
    component: Launch,
  },
]

@NgModule({
  declarations: [Launch],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Launch],
})
export class LaunchModule {}
