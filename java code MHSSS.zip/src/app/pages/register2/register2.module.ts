import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Register2 } from './register2.component'

const routes = [
  {
    path: '',
    component: Register2,
  },
]

@NgModule({
  declarations: [Register2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Register2],
})
export class Register2Module {}
