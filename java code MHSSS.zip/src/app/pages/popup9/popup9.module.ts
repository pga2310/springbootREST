import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Popup9 } from './popup9.component'

const routes = [
  {
    path: '',
    component: Popup9,
  },
]

@NgModule({
  declarations: [Popup9],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Popup9],
})
export class Popup9Module {}
