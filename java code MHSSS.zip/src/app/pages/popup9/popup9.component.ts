import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-popup9',
  templateUrl: 'popup9.component.html',
  styleUrls: ['popup9.component.css'],
})
export class Popup9 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
