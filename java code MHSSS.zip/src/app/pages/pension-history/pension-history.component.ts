import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'pension-history',
  templateUrl: 'pension-history.component.html',
  styleUrls: ['pension-history.component.css'],
})
export class PensionHistory {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
