import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { PensionHistory } from './pension-history.component'

const routes = [
  {
    path: '',
    component: PensionHistory,
  },
]

@NgModule({
  declarations: [PensionHistory],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [PensionHistory],
})
export class PensionHistoryModule {}
