import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-application1',
  templateUrl: 'application1.component.html',
  styleUrls: ['application1.component.css'],
})
export class Application1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
