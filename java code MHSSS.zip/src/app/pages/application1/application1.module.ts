import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Application1 } from './application1.component'

const routes = [
  {
    path: '',
    component: Application1,
  },
]

@NgModule({
  declarations: [Application1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Application1],
})
export class Application1Module {}
