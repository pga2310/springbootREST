import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Application4 } from './application4.component'

const routes = [
  {
    path: '',
    component: Application4,
  },
]

@NgModule({
  declarations: [Application4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Application4],
})
export class Application4Module {}
