import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-application4',
  templateUrl: 'application4.component.html',
  styleUrls: ['application4.component.css'],
})
export class Application4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
