import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Merchant2 } from './merchant2.component'

const routes = [
  {
    path: '',
    component: Merchant2,
  },
]

@NgModule({
  declarations: [Merchant2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Merchant2],
})
export class Merchant2Module {}
