import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-merchant2',
  templateUrl: 'merchant2.component.html',
  styleUrls: ['merchant2.component.css'],
})
export class Merchant2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
