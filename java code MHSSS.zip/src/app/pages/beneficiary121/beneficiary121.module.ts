import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary121 } from './beneficiary121.component'

const routes = [
  {
    path: '',
    component: Beneficiary121,
  },
]

@NgModule({
  declarations: [Beneficiary121],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary121],
})
export class Beneficiary121Module {}
