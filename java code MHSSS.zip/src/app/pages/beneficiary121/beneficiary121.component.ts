import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary121',
  templateUrl: 'beneficiary121.component.html',
  styleUrls: ['beneficiary121.component.css'],
})
export class Beneficiary121 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
