import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-pensioner2',
  templateUrl: 'pensioner2.component.html',
  styleUrls: ['pensioner2.component.css'],
})
export class Pensioner2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
