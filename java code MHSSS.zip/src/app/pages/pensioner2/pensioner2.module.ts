import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner2 } from './pensioner2.component'

const routes = [
  {
    path: '',
    component: Pensioner2,
  },
]

@NgModule({
  declarations: [Pensioner2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner2],
})
export class Pensioner2Module {}
