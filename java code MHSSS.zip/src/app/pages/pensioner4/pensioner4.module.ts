import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner4 } from './pensioner4.component'

const routes = [
  {
    path: '',
    component: Pensioner4,
  },
]

@NgModule({
  declarations: [Pensioner4],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner4],
})
export class Pensioner4Module {}
