import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-pensioner4',
  templateUrl: 'pensioner4.component.html',
  styleUrls: ['pensioner4.component.css'],
})
export class Pensioner4 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
