import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary111',
  templateUrl: 'beneficiary111.component.html',
  styleUrls: ['beneficiary111.component.css'],
})
export class Beneficiary111 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
