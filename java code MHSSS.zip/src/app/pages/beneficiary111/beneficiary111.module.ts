import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary111 } from './beneficiary111.component'

const routes = [
  {
    path: '',
    component: Beneficiary111,
  },
]

@NgModule({
  declarations: [Beneficiary111],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary111],
})
export class Beneficiary111Module {}
