import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Merchant5 } from './merchant5.component'

const routes = [
  {
    path: '',
    component: Merchant5,
  },
]

@NgModule({
  declarations: [Merchant5],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Merchant5],
})
export class Merchant5Module {}
