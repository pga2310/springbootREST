import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-merchant5',
  templateUrl: 'merchant5.component.html',
  styleUrls: ['merchant5.component.css'],
})
export class Merchant5 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
