import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary3',
  templateUrl: 'beneficiary3.component.html',
  styleUrls: ['beneficiary3.component.css'],
})
export class Beneficiary3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
