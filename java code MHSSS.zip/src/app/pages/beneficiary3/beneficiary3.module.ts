import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary3 } from './beneficiary3.component'

const routes = [
  {
    path: '',
    component: Beneficiary3,
  },
]

@NgModule({
  declarations: [Beneficiary3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary3],
})
export class Beneficiary3Module {}
