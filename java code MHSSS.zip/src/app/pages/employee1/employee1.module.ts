import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee1 } from './employee1.component'

const routes = [
  {
    path: '',
    component: Employee1,
  },
]

@NgModule({
  declarations: [Employee1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee1],
})
export class Employee1Module {}
