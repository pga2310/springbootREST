import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Accounts1 } from './accounts1.component'

const routes = [
  {
    path: '',
    component: Accounts1,
  },
]

@NgModule({
  declarations: [Accounts1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Accounts1],
})
export class Accounts1Module {}
