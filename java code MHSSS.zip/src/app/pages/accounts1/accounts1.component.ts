import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-accounts1',
  templateUrl: 'accounts1.component.html',
  styleUrls: ['accounts1.component.css'],
})
export class Accounts1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
