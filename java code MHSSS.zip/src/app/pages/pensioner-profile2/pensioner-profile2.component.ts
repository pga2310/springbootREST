import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'pensioner-profile2',
  templateUrl: 'pensioner-profile2.component.html',
  styleUrls: ['pensioner-profile2.component.css'],
})
export class PensionerProfile2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
