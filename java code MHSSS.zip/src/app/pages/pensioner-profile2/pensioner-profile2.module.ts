import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { PensionerProfile2 } from './pensioner-profile2.component'

const routes = [
  {
    path: '',
    component: PensionerProfile2,
  },
]

@NgModule({
  declarations: [PensionerProfile2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [PensionerProfile2],
})
export class PensionerProfile2Module {}
