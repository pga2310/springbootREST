import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { SocialWorker2 } from './social-worker2.component'

const routes = [
  {
    path: '',
    component: SocialWorker2,
  },
]

@NgModule({
  declarations: [SocialWorker2],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [SocialWorker2],
})
export class SocialWorker2Module {}
