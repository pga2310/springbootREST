import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'social-worker2',
  templateUrl: 'social-worker2.component.html',
  styleUrls: ['social-worker2.component.css'],
})
export class SocialWorker2 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
