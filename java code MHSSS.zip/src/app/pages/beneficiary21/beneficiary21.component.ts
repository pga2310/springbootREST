import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary21',
  templateUrl: 'beneficiary21.component.html',
  styleUrls: ['beneficiary21.component.css'],
})
export class Beneficiary21 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
