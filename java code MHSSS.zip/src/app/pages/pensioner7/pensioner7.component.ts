import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-pensioner7',
  templateUrl: 'pensioner7.component.html',
  styleUrls: ['pensioner7.component.css'],
})
export class Pensioner7 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
