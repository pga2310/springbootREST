import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner7 } from './pensioner7.component'

const routes = [
  {
    path: '',
    component: Pensioner7,
  },
]

@NgModule({
  declarations: [Pensioner7],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner7],
})
export class Pensioner7Module {}
