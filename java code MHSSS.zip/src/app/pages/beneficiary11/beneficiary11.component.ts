import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-beneficiary11',
  templateUrl: 'beneficiary11.component.html',
  styleUrls: ['beneficiary11.component.css'],
})
export class Beneficiary11 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
