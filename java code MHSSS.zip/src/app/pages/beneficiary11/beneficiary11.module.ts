import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Beneficiary11 } from './beneficiary11.component'

const routes = [
  {
    path: '',
    component: Beneficiary11,
  },
]

@NgModule({
  declarations: [Beneficiary11],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Beneficiary11],
})
export class Beneficiary11Module {}
