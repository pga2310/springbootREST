import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { ApplicationStatus3 } from './application-status3.component'

const routes = [
  {
    path: '',
    component: ApplicationStatus3,
  },
]

@NgModule({
  declarations: [ApplicationStatus3],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [ApplicationStatus3],
})
export class ApplicationStatus3Module {}
