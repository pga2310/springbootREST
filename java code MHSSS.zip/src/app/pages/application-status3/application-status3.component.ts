import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'application-status3',
  templateUrl: 'application-status3.component.html',
  styleUrls: ['application-status3.component.css'],
})
export class ApplicationStatus3 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
