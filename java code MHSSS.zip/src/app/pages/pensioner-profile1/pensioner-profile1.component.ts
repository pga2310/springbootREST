import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'pensioner-profile1',
  templateUrl: 'pensioner-profile1.component.html',
  styleUrls: ['pensioner-profile1.component.css'],
})
export class PensionerProfile1 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
