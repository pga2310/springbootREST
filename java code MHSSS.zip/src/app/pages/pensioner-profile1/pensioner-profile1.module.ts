import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { PensionerProfile1 } from './pensioner-profile1.component'

const routes = [
  {
    path: '',
    component: PensionerProfile1,
  },
]

@NgModule({
  declarations: [PensionerProfile1],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [PensionerProfile1],
})
export class PensionerProfile1Module {}
