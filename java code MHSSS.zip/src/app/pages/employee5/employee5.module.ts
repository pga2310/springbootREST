import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Employee5 } from './employee5.component'

const routes = [
  {
    path: '',
    component: Employee5,
  },
]

@NgModule({
  declarations: [Employee5],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Employee5],
})
export class Employee5Module {}
