import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-employee5',
  templateUrl: 'employee5.component.html',
  styleUrls: ['employee5.component.css'],
})
export class Employee5 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
