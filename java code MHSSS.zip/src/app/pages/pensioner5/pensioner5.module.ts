import { NgModule } from '@angular/core'
import { RouterModule } from '@angular/router'
import { CommonModule } from '@angular/common'

import { ComponentsModule } from '../../components/components.module'
import { Pensioner5 } from './pensioner5.component'

const routes = [
  {
    path: '',
    component: Pensioner5,
  },
]

@NgModule({
  declarations: [Pensioner5],
  imports: [CommonModule, ComponentsModule, RouterModule.forChild(routes)],
  exports: [Pensioner5],
})
export class Pensioner5Module {}
