import { Component } from '@angular/core'
import { Title } from '@angular/platform-browser'

@Component({
  selector: 'app-pensioner5',
  templateUrl: 'pensioner5.component.html',
  styleUrls: ['pensioner5.component.css'],
})
export class Pensioner5 {
  constructor(private title: Title) {
    this.title.setTitle('exported project')
  }
}
